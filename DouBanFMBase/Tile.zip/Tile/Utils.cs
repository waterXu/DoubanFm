﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DouBanFMBase.Tile
{
    public class Utils
    {
        private static readonly Version _targetedVersion8 = new Version(8, 0);
        private static readonly Version _targetedVersion78 = new Version(7, 10, 8858);

        public static bool CanUseLiveTiles
        {
            get { return Environment.OSVersion.Version >= _targetedVersion78; }
        }

        public static bool IsWP8
        {
            get { return Environment.OSVersion.Version >= _targetedVersion8; }
        }

        #region private

        internal static void SetProperty(object instance, string name, object value)
        {
            MethodInfo setMethod = instance.GetType().GetProperty(name).GetSetMethod();
            setMethod.Invoke(instance, new[] { value });
        }


        internal static object GetProperty(object instance, string name)
        {
            return instance.GetType().GetProperty(name).GetValue(instance, new Object[] { });
        }

        #endregion
    }
}
